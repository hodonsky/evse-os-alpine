"use strict"

export interface IRegionBounds { top: number; left: number; width: number; height: number }